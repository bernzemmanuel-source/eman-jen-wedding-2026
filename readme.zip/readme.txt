Payment QR images used in the Gift Note section:
- unionbank-qr.png
- gcash-qr.png
The Capture the Love QR supplied by you is included as capture-the-love-qr.png.
